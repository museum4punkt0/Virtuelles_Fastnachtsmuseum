<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

include_once( 'scrollmagic.shortcode.php' );
include_once( 'imagesequence.shortcode.php' );
include_once( 'single_image.shortcode.php' );
include_once( 'image_group.shortcode.php' );
include_once( 'empty_space.shortcode.php' );