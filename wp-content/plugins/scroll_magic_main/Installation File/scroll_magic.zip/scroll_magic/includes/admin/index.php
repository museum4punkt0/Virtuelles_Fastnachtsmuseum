<?php
// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

include_once 'scrollmagic.class.php';
include_once 'options.class.php';
