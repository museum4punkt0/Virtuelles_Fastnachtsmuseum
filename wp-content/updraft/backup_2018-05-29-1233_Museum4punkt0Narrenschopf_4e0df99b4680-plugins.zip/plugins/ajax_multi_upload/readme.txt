---Instalation---
1. Login into your WordPress admin panel.
2. Go to Admin Panel->Plugins->Add New->Upload
3. Select codecanyon-144658-ajax-multi-upload-for-wordpress.zip file
4. Activate plugin